#!/usr/bin/env python3
"""Generate the neo-10 daily onboarding feed — one CSV per business date.

The upstream "warehouse" drops one file each morning. A file carries every
application SUBMITTED that day plus every application whose state CHANGED that
day, so a row first seen as IN_PROGRESS reappears days later as COMPLETED with
a granted limit and a decided_at. Loading it is therefore an upsert on
application_id, not an insert.

Deterministic: seed 42. Two runs produce byte-identical output. Nothing here
reads the wall clock.

Usage:
    python3 generate_daily_feed.py [--out data] [--emit csv|sql|both]
    python3 generate_daily_feed.py --emit sql --advance-to 2026-07-15

Part 1 (the file feed) uses --emit csv. Part 2 (the table feed) uses --emit sql,
over the SAME generated applications — two emitters, one dataset, which is what
makes the two ingestion paths provably equivalent.
"""
import argparse
import csv
import datetime as dt
import os
import random
import sys

SEED = 42
PERIOD_START = dt.date(2026, 1, 1)
PERIOD_END = dt.date(2026, 7, 28)

# ---------------------------------------------------------------------------
# Vocabulary. Everything here is the LIVE system's, except where marked.
# ---------------------------------------------------------------------------

# The eight business steps. The orchestrator currently dispatches ten (neo09
# support, neo10 analytics), but neither decides an application — they observe.
# CLAUDE.md 18 carries their removal from the sequence as an open item.
STEPS = [
    "verification", "policy", "kyc", "screening",
    "credit", "agreement", "account", "card",
]

# From neo-00's ApplicationFactory: (minLimit, maxLimit) are the LIVE values.
# apr and min_income are INSTRUCTOR-SUPPLIED — the contract's APR catalogue
# (29.9 / 24.9 / 34.9) belongs to STANDARD/REWARDS/STUDENT, and the two live
# product codes have no APR anywhere. Do not cite these as contract values.
PRODUCTS = {
    "CREDIT_CARD_PREMIUM": {"min_limit": 500, "max_limit": 10000,
                            "apr": 24.9, "min_income": 18000, "weight": 62},
    "CREDIT_CARD_PLATINUM": {"min_limit": 5000, "max_limit": 25000,
                             "apr": 19.9, "min_income": 30000, "weight": 38},
}

CHANNELS = [("WEB", 34), ("MOBILE_APP", 41), ("BRANCH", 12), ("AGGREGATOR", 13)]

AGE_BANDS = [("18-24", 14), ("25-34", 31), ("35-44", 24),
             ("45-54", 16), ("55-64", 10), ("65+", 5)]

# Supported / excluded lists are api-contract v2's; the high-risk pair drives
# the screening story.
COUNTRIES = [("GB", 71), ("IE", 6), ("PL", 6), ("DE", 5), ("FR", 4),
             ("ES", 3), ("NL", 3), ("US", 1), ("RU", 1)]
EXCLUDED_COUNTRIES = {"US"}
HIGH_RISK_COUNTRIES = {"RU"}

EMPLOYMENT = [("PERMANENT", 55), ("CONTRACT", 13), ("SELF_EMPLOYED", 14),
              ("STUDENT", 7), ("RETIRED", 7), ("UNEMPLOYED", 4)]

# Reason codes are api-contract v2's registry, verbatim. This module consumes
# them; it owns none of them.
REJECT_REASONS = {
    "verification": ["VER_MISSING_FIELD", "VER_INVALID_FIELD",
                     "VER_AGE_BELOW_MINIMUM",
                     "VER_LIMIT_OUTSIDE_PRODUCT_RANGE",
                     "VER_TERMS_NOT_ACCEPTED"],
    "policy": ["POL_TAX_RESIDENCY_EXCLUDED", "POL_EXISTING_PRODUCT_HELD",
               "POL_TAX_RESIDENCY_UNSUPPORTED", "POL_CUSTOMER_BLOCKED"],
    "kyc": ["KYC_DOCUMENT_INVALID", "KYC_DOCUMENT_EXPIRED",
            "KYC_PROVIDER_UNAVAILABLE"],
    "screening": ["SCR_EXACT_MATCH", "SCR_HIGH_RISK_COUNTRY"],
    "credit": ["CRE_INCOME_BELOW_MINIMUM", "CRE_AFFORDABILITY_EXCEEDED"],
    "agreement": ["AGR_DECLINED_BY_CUSTOMER", "AGR_EXPIRED_UNSIGNED"],
    "account": ["ACC_DUPLICATE_PREVENTED", "ACC_CORE_UNAVAILABLE"],
    "card": ["CRD_DELIVERY_ADDRESS_INVALID", "CRD_BUREAU_UNAVAILABLE"],
}
REFER_REASONS = {
    "verification": ["VER_INVALID_FIELD"],
    "policy": ["POL_TAX_RESIDENCY_UNSUPPORTED"],
    "kyc": ["KYC_LOW_CONFIDENCE"],
    "screening": ["SCR_PARTIAL_MATCH", "SCR_HIGH_RISK_COUNTRY"],
    "credit": ["CRE_AFFORDABILITY_EXCEEDED"],
    "agreement": ["AGR_PENDING_SIGNATURE"],
    "account": ["ACC_CORE_UNAVAILABLE"],
    "card": ["CRD_BUREAU_UNAVAILABLE"],
}
FAIL_REASONS = {
    "kyc": ["KYC_PROVIDER_UNAVAILABLE"],
    "agreement": ["AGR_PROVIDER_UNAVAILABLE"],
    "account": ["ACC_CORE_UNAVAILABLE"],
    "card": ["CRD_BUREAU_UNAVAILABLE"],
}

# (p_reject, p_refer, p_fail) per step, conditional on reaching it.
STEP_RISK = {
    "verification": (0.035, 0.005, 0.000),
    "policy":       (0.030, 0.012, 0.000),
    "kyc":          (0.022, 0.025, 0.004),
    "screening":    (0.012, 0.028, 0.000),
    "credit":       (0.055, 0.035, 0.000),
    "agreement":    (0.020, 0.003, 0.003),
    "account":      (0.004, 0.004, 0.003),
    "card":         (0.003, 0.004, 0.003),
}

# Typical minutes a step takes. Agreement waits on a human, so it is the long
# pole and the reason journeys straddle days at all.
STEP_MINUTES = {
    "verification": (2, 40), "policy": (2, 35), "kyc": (10, 240),
    "screening": (1, 20), "credit": (15, 420), "agreement": (30, 3600),
    "account": (10, 150), "card": (20, 300),
}

COLUMNS = [
    # --- the 12 required ------------------------------------------------
    "application_id", "submitted_at", "channel", "product_code",
    "requested_limit", "status", "steps_reached", "stopped_at_step",
    "decline_reason_code", "decided_at", "granted_limit", "last_updated_at",
    # --- the 10 optional ------------------------------------------------
    "age_band", "residence_country", "employment_status", "annual_income",
    "dti_ratio", "credit_band", "apr", "screening_outcome", "kyc_outcome",
    "agreement_outcome",
]

# ---------------------------------------------------------------------------
# Planted anomalies. Each one is a real production failure mode, and each has
# an exact answer in answers.md.
# ---------------------------------------------------------------------------
MISSING_FILE_DATE = dt.date(2026, 4, 17)     # 1 the file that never arrived
SPIKE_DATE = dt.date(2026, 3, 12)            # 6 the campaign day
SPIKE_MULTIPLIER = 4
PLATINUM_DIP_START = dt.date(2026, 6, 8)     # 7 the week PLATINUM sagged
PLATINUM_DIP_END = dt.date(2026, 6, 14)
MALFORMED_PER_N_FILES = 17                   # 3 spread thinly, not clustered


def weighted(rng, pairs):
    total = sum(w for _, w in pairs)
    r = rng.uniform(0, total)
    upto = 0.0
    for value, w in pairs:
        upto += w
        if r <= upto:
            return value
    return pairs[-1][0]


def iso(ts):
    return ts.strftime("%Y-%m-%dT%H:%M:%SZ")


def business_dates():
    d = PERIOD_START
    while d <= PERIOD_END:
        yield d
        d += dt.timedelta(days=1)


def daily_volume(rng, day):
    """Weekdays busier than weekends; one campaign spike."""
    base = 14 if day.weekday() < 5 else 8
    n = max(1, int(rng.gauss(base, base * 0.22)))
    if day == SPIKE_DATE:
        n *= SPIKE_MULTIPLIER
    return n


def submit_time(rng, day, spike):
    """Business hours, with an evening tail. Campaign traffic skews late."""
    hour = rng.choice([9, 10, 10, 11, 11, 12, 13, 14, 14, 15, 16, 17, 18,
                       19, 20, 21] + ([20, 21, 22] if spike else []))
    return dt.datetime(day.year, day.month, day.day, hour,
                       rng.randrange(60), rng.randrange(60))


def make_applicant(rng, day):
    spike = day == SPIKE_DATE
    channel = "AGGREGATOR" if (spike and rng.random() < 0.72) \
        else weighted(rng, CHANNELS)
    age_band = weighted(rng, AGE_BANDS)
    country = weighted(rng, COUNTRIES)
    employment = weighted(rng, EMPLOYMENT)

    if employment == "STUDENT":
        income = rng.randrange(4000, 16000, 500)
    elif employment == "UNEMPLOYED":
        income = rng.randrange(0, 12000, 500)
    elif employment == "RETIRED":
        income = rng.randrange(11000, 34000, 500)
    else:
        income = int(min(180000, max(9000, rng.lognormvariate(10.55, 0.46))))
        income = round(income / 500) * 500

    product = weighted(rng, [(k, v["weight"]) for k, v in PRODUCTS.items()])
    spec = PRODUCTS[product]
    ask = rng.randrange(spec["min_limit"], spec["max_limit"] + 1, 250)
    # Campaign traffic asks for more than it can afford — that is the story.
    if spike:
        ask = min(spec["max_limit"], ask + rng.randrange(0, 4000, 250))

    monthly_income = max(income, 1) / 12.0
    housing = rng.uniform(0.14, 0.38) * monthly_income
    commitments = rng.uniform(0.02, 0.18) * monthly_income
    dti = round(min(1.4, (housing + commitments) / max(monthly_income, 1)), 2)

    if dti <= 0.26 and income >= 45000:
        band = "A"
    elif dti <= 0.34 and income >= 30000:
        band = "B"
    elif dti <= 0.45 and income >= 20000:
        band = "C"
    elif dti <= 0.52:
        band = "D"
    else:
        band = "E"

    return {
        "channel": channel, "age_band": age_band, "residence_country": country,
        "employment_status": employment, "annual_income": income,
        "product_code": product, "requested_limit": ask,
        "dti_ratio": dti, "credit_band": band,
        "apr": spec["apr"], "_spike": spike,
    }


def step_verdict(rng, step, app, day):
    """Decide one step. Returns 'pass' | 'reject' | 'refer' | 'fail'."""
    p_reject, p_refer, p_fail = STEP_RISK[step]
    spec = PRODUCTS[app["product_code"]]

    # Rules the earlier teams actually implement, so the data tells their story.
    if step == "verification":
        if app["age_band"] == "18-24" and rng.random() < 0.035:
            return "reject"  # VER_AGE_BELOW_MINIMUM
        if not (spec["min_limit"] <= app["requested_limit"] <= spec["max_limit"]):
            return "reject"
    if step == "policy" and app["residence_country"] in EXCLUDED_COUNTRIES:
        return "reject"      # POL_TAX_RESIDENCY_EXCLUDED
    if step == "screening" and app["residence_country"] in HIGH_RISK_COUNTRIES:
        return "refer" if rng.random() < 0.6 else "reject"
    if step == "credit":
        if app["annual_income"] < spec["min_income"]:
            p_reject += 0.45                       # CRE_INCOME_BELOW_MINIMUM
        elif app["dti_ratio"] > 0.45:
            p_reject += 0.22                       # CRE_AFFORDABILITY_EXCEEDED
        elif app["dti_ratio"] > 0.40:
            p_refer += 0.12
        # Aggregator traffic is price-shopping, thinner on affordability and
        # structurally worse — a real effect, and what makes the campaign day
        # explicable rather than merely odd.
        if app["channel"] == "AGGREGATOR":
            p_reject += 0.055
        if app["_spike"]:
            p_reject += 0.12
        # The one-week PLATINUM dip: a tightened policy nobody announced.
        if (app["product_code"] == "CREDIT_CARD_PLATINUM"
                and PLATINUM_DIP_START <= day <= PLATINUM_DIP_END):
            p_reject += 0.34

    r = rng.random()
    if r < p_reject:
        return "reject"
    if r < p_reject + p_refer:
        return "refer"
    if r < p_reject + p_refer + p_fail:
        return "fail"
    return "pass"


def run_journey(rng, app, submitted):
    """Walk the eight steps. Returns the event list that drives the files.

    An event is (timestamp, state-dict). One row is emitted per day on which
    at least one event happened, carrying the state at the END of that day.
    """
    events = []
    state = {
        "status": "IN_PROGRESS", "steps_reached": 0,
        "stopped_at_step": STEPS[0], "decline_reason_code": "",
        "decided_at": "", "granted_limit": "",
        "screening_outcome": "", "kyc_outcome": "", "agreement_outcome": "",
    }
    events.append((submitted, dict(state)))

    now = submitted
    for index, step in enumerate(STEPS):
        low, high = STEP_MINUTES[step]
        now += dt.timedelta(minutes=rng.randrange(low, high + 1),
                            seconds=rng.randrange(60))
        verdict = step_verdict(rng, step, app, now.date())

        if step == "kyc":
            state["kyc_outcome"] = {"pass": "VERIFIED", "refer": "REVIEW",
                                    "reject": "FAILED", "fail": "FAILED"}[verdict]
        if step == "screening":
            state["screening_outcome"] = {"pass": "CLEAR", "refer": "REVIEW",
                                          "reject": "HIT", "fail": "REVIEW"}[verdict]
        if step == "agreement":
            state["agreement_outcome"] = {"pass": "SIGNED", "refer": "PENDING",
                                          "reject": "DECLINED", "fail": "EXPIRED"}[verdict]

        if verdict == "pass":
            state["steps_reached"] = index + 1
            if index + 1 < len(STEPS):
                state["stopped_at_step"] = STEPS[index + 1]
            else:
                spec = PRODUCTS[app["product_code"]]
                affordable = int(app["annual_income"] * 0.28 / 250) * 250
                granted = max(spec["min_limit"],
                              min(app["requested_limit"], spec["max_limit"],
                                  max(affordable, spec["min_limit"])))
                state.update(status="COMPLETED", stopped_at_step="",
                             decided_at=iso(now), granted_limit=str(granted))
            events.append((now, dict(state)))
            if state["status"] == "COMPLETED":
                return events
            continue

        state["stopped_at_step"] = step
        if verdict == "reject":
            state.update(status="REJECTED", decided_at=iso(now),
                         decline_reason_code=rng.choice(REJECT_REASONS[step]))
        elif verdict == "fail":
            state.update(status="FAILED", decided_at=iso(now),
                         decline_reason_code=rng.choice(FAIL_REASONS.get(
                             step, ["ACC_CORE_UNAVAILABLE"])))
        else:
            state.update(status="REFERRED", decided_at=iso(now),
                         decline_reason_code=rng.choice(REFER_REASONS[step]))
        events.append((now, dict(state)))

        # A third of referrals come back to an analyst days later. This is what
        # makes a row appear in three files, and is the reason the loader has to
        # be an upsert rather than an insert.
        if verdict == "refer" and rng.random() < 0.34:
            later = now + dt.timedelta(days=rng.randrange(1, 6),
                                       hours=rng.randrange(0, 9),
                                       minutes=rng.randrange(60))
            resolved = dict(state)
            if rng.random() < 0.63:
                spec = PRODUCTS[app["product_code"]]
                affordable = int(app["annual_income"] * 0.24 / 250) * 250
                granted = max(spec["min_limit"],
                              min(app["requested_limit"], spec["max_limit"],
                                  max(affordable, spec["min_limit"])))
                resolved.update(status="COMPLETED", steps_reached=len(STEPS),
                                stopped_at_step="", decline_reason_code="",
                                decided_at=iso(later), granted_limit=str(granted))
                if resolved["agreement_outcome"] in ("", "PENDING"):
                    resolved["agreement_outcome"] = "SIGNED"
            else:
                resolved.update(status="REJECTED", decided_at=iso(later))
            events.append((later, resolved))
        return events

    return events


def build_applications():
    rng = random.Random(SEED)
    applications = []
    serial = 0
    for day in business_dates():
        for _ in range(daily_volume(rng, day)):
            serial += 1
            app = make_applicant(rng, day)
            submitted = submit_time(rng, day, app["_spike"])
            app["application_id"] = "APP-2026-%05d" % serial
            app["submitted_at"] = submitted
            app["events"] = run_journey(rng, app, submitted)
            applications.append(app)
    applications.sort(key=lambda a: (a["submitted_at"], a["application_id"]))
    return applications, rng


def row_for(app, state, last_updated):
    return {
        "application_id": app["application_id"],
        "submitted_at": iso(app["submitted_at"]),
        "channel": app["channel"],
        "product_code": app["product_code"],
        "requested_limit": str(app["requested_limit"]),
        "status": state["status"],
        "steps_reached": str(state["steps_reached"]),
        "stopped_at_step": state["stopped_at_step"],
        "decline_reason_code": state["decline_reason_code"],
        "decided_at": state["decided_at"],
        "granted_limit": state["granted_limit"],
        "last_updated_at": iso(last_updated),
        "age_band": app["age_band"],
        "residence_country": app["residence_country"],
        "employment_status": app["employment_status"],
        "annual_income": str(app["annual_income"]),
        "dti_ratio": "%.2f" % app["dti_ratio"],
        "credit_band": app["credit_band"],
        "apr": "%.1f" % app["apr"],
        "screening_outcome": state["screening_outcome"],
        "kyc_outcome": state["kyc_outcome"],
        "agreement_outcome": state["agreement_outcome"],
    }


def build_daily_rows(applications):
    """Group every application's events into one row per (day, application).

    The state carried is the state at the END of that day, stamped with the
    last event timestamp on it — which is exactly what last_updated_at means.
    """
    by_day = {}
    for app in applications:
        per_day = {}
        for ts, state in app["events"]:
            if ts.date() > PERIOD_END:
                continue          # still running when the period closed
            per_day[ts.date()] = (ts, state)
        for day, (ts, state) in per_day.items():
            by_day.setdefault(day, []).append(row_for(app, state, ts))
    for day in by_day:
        by_day[day].sort(key=lambda r: (r["last_updated_at"],
                                        r["application_id"]))
    return by_day


def plant_anomalies(by_day, applications):
    """Anomalies 2, 4 and 5. 1, 6 and 7 are already in the data above.

    Returns a dict of exactly what was planted, so answers.md can state it and
    the verifier can assert it.
    """
    rng = random.Random(SEED + 1)
    planted = {}
    days = sorted(by_day)

    # 2 A RESTATEMENT: an immutable column changes in a later file. The loader
    #   must not swallow this silently — it counts as `restated` and shows up.
    candidates = [(d, r) for d in days for r in by_day[d]
                  if d > dt.date(2026, 2, 1) and r["status"] == "IN_PROGRESS"]
    restated_id = None
    for day, row in candidates:
        later = [(d, r) for d in days if d > day
                 for r in by_day[d] if r["application_id"] == row["application_id"]]
        if later:
            restated_id = row["application_id"]
            original = int(row["requested_limit"])
            corrected = original + 1500
            for d, r in later:
                r["requested_limit"] = str(corrected)
            planted["restatement"] = {
                "application_id": restated_id,
                "first_seen": day.isoformat(),
                "original_requested_limit": original,
                "restated_requested_limit": corrected,
                "restated_in_files": sorted(d.isoformat() for d, _ in later),
            }
            break

    # 4 A DUPLICATE application_id WITHIN ONE FILE, second occurrence newer.
    #   Filename-level dedupe cannot see this; only a row-level rule can.
    dup_day = dt.date(2026, 5, 20)
    if dup_day in by_day and by_day[dup_day]:
        source = by_day[dup_day][len(by_day[dup_day]) // 2]
        twin = dict(source)
        bumped = (dt.datetime.strptime(source["last_updated_at"],
                                       "%Y-%m-%dT%H:%M:%SZ")
                  + dt.timedelta(minutes=11))
        twin["last_updated_at"] = iso(bumped)
        twin["stopped_at_step"] = source["stopped_at_step"]
        by_day[dup_day].append(twin)
        by_day[dup_day].sort(key=lambda r: (r["last_updated_at"],
                                            r["application_id"]))
        planted["duplicate_in_file"] = {
            "business_date": dup_day.isoformat(),
            "application_id": source["application_id"],
            "older_last_updated_at": source["last_updated_at"],
            "newer_last_updated_at": twin["last_updated_at"],
        }

    # 5 AN OUT-OF-ORDER UPDATE: a later file carrying an OLDER last_updated_at
    #   than one already loaded. Applying it would undo a decision.
    for day in days:
        if day < dt.date(2026, 6, 1):
            continue
        for row in by_day[day]:
            earlier = [(d, r) for d in days if d < day
                       for r in by_day[d]
                       if r["application_id"] == row["application_id"]]
            if earlier and row["status"] in ("COMPLETED", "REJECTED"):
                prior_day, prior = earlier[-1]
                stale = dict(prior)
                stale["last_updated_at"] = iso(
                    dt.datetime.strptime(prior["last_updated_at"],
                                         "%Y-%m-%dT%H:%M:%SZ")
                    - dt.timedelta(minutes=4))
                nxt = next(d for d in days if d > day)
                by_day[nxt].append(stale)
                by_day[nxt].sort(key=lambda r: (r["last_updated_at"],
                                                r["application_id"]))
                planted["out_of_order"] = {
                    "application_id": row["application_id"],
                    "arrives_in_file": nxt.isoformat(),
                    "carries_last_updated_at": stale["last_updated_at"],
                    "already_loaded_last_updated_at": row["last_updated_at"],
                    "must_be_counted_as": "unchanged",
                }
                break
        if "out_of_order" in planted:
            break

    # 1 THE FILE THAT NEVER ARRIVED. Same-day-decided applications from that
    #   date are lost for good — a gap is not cosmetic.
    lost = []
    if MISSING_FILE_DATE in by_day:
        ids_in_missing = {r["application_id"] for r in by_day[MISSING_FILE_DATE]}
        elsewhere = {r["application_id"] for d in days if d != MISSING_FILE_DATE
                     for r in by_day[d]}
        lost = sorted(ids_in_missing - elsewhere)
        del by_day[MISSING_FILE_DATE]
    planted["missing_file"] = {
        "business_date": MISSING_FILE_DATE.isoformat(),
        "applications_lost_for_good": len(lost),
        "example_lost_ids": lost[:5],
    }

    # 8 A TIE GROUP — several DIFFERENT applications sharing one exact
    #   last_updated_at. Harmless to a file loader (it reads the whole file),
    #   and the classic way a watermark-paged table reader silently loses rows:
    #   `WHERE last_updated_at > :w LIMIT n` skips the rest of the group,
    #   `>=` re-reads it forever. Part 2's trap 1.
    tie_day = dt.date(2026, 2, 24)
    if tie_day in by_day:
        group = [r for r in by_day[tie_day]][:12]
        if len(group) >= 6:
            stamp = group[0]["last_updated_at"]
            for row in group:
                row["last_updated_at"] = stamp
            planted["tie_group"] = {
                "business_date": tie_day.isoformat(),
                "last_updated_at": stamp,
                "rows": len(group),
                "application_ids": sorted(r["application_id"] for r in group),
            }

    # 9 A ROW DELETED AT SOURCE — Part 2 only. A file feed cannot express this
    #   and neither can a watermark: the row simply stops existing and nothing
    #   tells the reader. Named so the answer key can state the accepted limit.
    early = sorted(by_day)[40]
    if by_day[early]:
        victim = by_day[early][0]["application_id"]
        planted["source_delete"] = {
            "application_id": victim,
            "deleted_on": sorted(by_day)[120].isoformat(),
        }

    planted["spike"] = {"business_date": SPIKE_DATE.isoformat(),
                        "multiplier": SPIKE_MULTIPLIER}
    planted["platinum_dip"] = {"from": PLATINUM_DIP_START.isoformat(),
                               "to": PLATINUM_DIP_END.isoformat()}
    planted["_rng_check"] = rng.random()
    for day in by_day:                # planting changed some timestamps
        by_day[day].sort(key=lambda r: (r["last_updated_at"],
                                        r["application_id"]))
    return planted


def plant_malformed(by_day):
    """3 MALFORMED ROWS, spread thinly. Each must reject ITS OWN LINE and let
    the rest of the file load — a 422 that kills the file loses good data."""
    rng = random.Random(SEED + 2)
    days = sorted(by_day)
    broken = []
    kinds = [
        ("bad_date", lambda r: r.update(submitted_at="17/03/2026 09:14")),
        ("unknown_enum", lambda r: r.update(channel="POST")),
        ("missing_key", lambda r: r.update(application_id="")),
        ("non_numeric", lambda r: r.update(requested_limit="three thousand")),
        ("bad_status", lambda r: r.update(status="APPROVED")),
    ]
    for index, day in enumerate(days):
        if index % MALFORMED_PER_N_FILES != 5 or not by_day[day]:
            continue
        kind, mutate = kinds[(index // MALFORMED_PER_N_FILES) % len(kinds)]
        victim = dict(by_day[day][len(by_day[day]) // 3])
        victim["_malformed"] = kind
        mutate(victim)
        by_day[day].append(victim)
        broken.append({"business_date": day.isoformat(), "kind": kind})
    return broken


def emit_csv(by_day, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    for day in sorted(by_day):
        path = os.path.join(out_dir, "neo_daily_%s.csv" % day.isoformat())
        with open(path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=COLUMNS,
                                    extrasaction="ignore", lineterminator="\n")
            writer.writeheader()
            for row in by_day[day]:
                writer.writerow(row)
    return len(by_day)


NUMERIC_COLUMNS = {"requested_limit", "steps_reached", "granted_limit",
                   "annual_income", "dti_ratio", "apr"}


def emit_sql(by_day, out_dir, advance_to, planted):
    """Part 2's emitter: the same rows as in-place UPSERTs against the
    simulated upstream table. Replaying days 1..N leaves feed_application
    holding exactly the state the CSVs describe at day N — which is what makes
    the two ingestion paths comparable.

    One multi-row INSERT per business date, so the file stays about a megabyte
    rather than repeating a 22-column upsert clause 4,500 times.
    """
    os.makedirs(out_dir, exist_ok=True)
    days = [d for d in sorted(by_day) if advance_to is None or d <= advance_to]
    path = os.path.join(out_dir, "feed_application_replay.sql")
    cols = ", ".join(COLUMNS)
    updates = ",\n    ".join("%s = new.%s" % (c, c) for c in COLUMNS
                             if c != "application_id")
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(
            "-- Generated by generate_daily_feed.py (seed %d).\n"
            "-- One transaction per business date: this is the upstream source\n"
            "-- system mutating IN PLACE. Nothing here remembers a row's\n"
            "-- previous value — which is exactly the property the daily files\n"
            "-- had and this table does not.\n"
            "--\n"
            "-- Malformed rows are absent by construction: a typed column\n"
            "-- cannot hold '17/03/2026'. That is the trade — the table takes\n"
            "-- the parsing problems away and hands you ordering problems.\n"
            "USE neo_10_feed;\n\n" % SEED)
        for day in days:
            rows = [r for r in by_day[day] if not r.get("_malformed")]
            if not rows:
                continue
            handle.write("-- ---- business date %s (%d rows) ----\n"
                         "START TRANSACTION;\n" % (day.isoformat(), len(rows)))
            tuples = ",\n  ".join(
                "(" + ", ".join(sql_literal(r[c], c) for c in COLUMNS) + ")"
                for r in rows)
            handle.write("INSERT INTO feed_application (%s)\nVALUES\n  %s\n"
                         "AS new ON DUPLICATE KEY UPDATE\n    %s;\n"
                         % (cols, tuples, updates))
            drop = planted.get("source_delete") or {}
            if drop.get("deleted_on") == day.isoformat():
                handle.write(
                    "-- The source system deleted this application. A file\n"
                    "-- feed cannot express a deletion and neither can a\n"
                    "-- watermark: the row stops existing and nothing tells\n"
                    "-- the reader. raw_data will hold it forever.\n"
                    "DELETE FROM feed_application WHERE application_id = %s;\n"
                    % sql_literal(drop["application_id"]))
            handle.write("COMMIT;\n\n")
    return path, len(days)


def sql_literal(value, column=None):
    if value == "":
        return "NULL"
    if column in NUMERIC_COLUMNS:
        return str(value)
    return "'" + str(value).replace("\\", "\\\\").replace("'", "''") + "'"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "data"))
    parser.add_argument("--emit", choices=["csv", "sql", "both"], default="csv")
    parser.add_argument("--advance-to", default=None,
                        help="SQL emitter only: replay up to this business "
                             "date (YYYY-MM-DD) instead of the whole period")
    args = parser.parse_args()

    advance_to = (dt.datetime.strptime(args.advance_to, "%Y-%m-%d").date()
                  if args.advance_to else None)

    applications, _ = build_applications()
    by_day = build_daily_rows(applications)
    planted = plant_anomalies(by_day, applications)
    planted["malformed"] = plant_malformed(by_day)

    if args.emit in ("csv", "both"):
        files = emit_csv(by_day, args.out)
        print("csv  : %d daily files in %s" % (files, args.out))
    if args.emit in ("sql", "both"):
        path, days = emit_sql(by_day, args.out, advance_to, planted)
        print("sql  : %d business dates replayed into %s" % (days, path))
        print("tie  : %d rows share %s (part 2, trap 1)"
              % (planted.get("tie_group", {}).get("rows", 0),
                 planted.get("tie_group", {}).get("last_updated_at", "-")))
        print("del  : %s deleted at source on %s (part 2, trap 3)"
              % (planted.get("source_delete", {}).get("application_id", "-"),
                 planted.get("source_delete", {}).get("deleted_on", "-")))

    total_rows = sum(len(rows) for rows in by_day.values())
    print("apps : %d generated, %d rows across all files"
          % (len(applications), total_rows))
    print("gap  : %s (file never produced, %d applications lost)"
          % (planted["missing_file"]["business_date"],
             planted["missing_file"]["applications_lost_for_good"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
