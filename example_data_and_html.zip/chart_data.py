#!/usr/bin/env python3
"""Compute every number drawn on dashboards.html, from the CSVs alone.

Emits chart_data.json, which is inlined into dashboards.html so that page stays
self-contained and offline. Re-run after regenerating the feed, then paste the
file's contents over the DATA constant in the HTML.

This is a COUNTER for the mock's figures — not a reference loader. It has no
database, no rejection table, no gap report and no batch semantics. Building
those is team 10's work.
"""
import csv
import datetime as dt
import glob
import json
import os
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from verify_feed import (STEPS, load, final_states, funnel, parse_ts)  # noqa

HERE = os.path.dirname(os.path.abspath(__file__))

INCOME_BANDS = [("< £15k", 0, 15000), ("£15–25k", 15000, 25000),
                ("£25–40k", 25000, 40000), ("£40–60k", 40000, 60000),
                ("£60k+", 60000, 10 ** 9)]
DTI_BANDS = [("≤ 0.25", 0, 0.25), ("0.26–0.35", 0.25, 0.35),
             ("0.36–0.45", 0.35, 0.45), ("0.46–0.55", 0.45, 0.55),
             ("> 0.55", 0.55, 9)]
ASK_BANDS = [("£500–2.5k", 500, 2500), ("£2.5–5k", 2500, 5000),
             ("£5–10k", 5000, 10000), ("£10–15k", 10000, 15000),
             ("£15–25k", 15000, 25001)]
# FAILED is deliberately NOT in the categorical stack: a system timeout is not
# a business outcome, and mixing them in one donut is a real reporting error.
# It is reported separately, with its own figure.
OUTCOMES = ["COMPLETED", "REJECTED", "REFERRED", "IN_PROGRESS"]


def band_of(value, bands):
    for label, low, high in bands:
        if low <= value < high:
            return label
    return bands[-1][0]


def split(rows, key):
    out = defaultdict(Counter)
    for r in rows:
        out[key(r)][r["status"]] += 1
    return out


def as_series(grouped, order=None):
    keys = order or sorted(grouped, key=lambda k: -sum(grouped[k].values()))
    return [{"label": k, "total": sum(grouped[k].values()),
             "counts": {o: grouped[k][o] for o in OUTCOMES},
             "failed": grouped[k]["FAILED"]} for k in keys]


def main():
    files, rows, bad, per_file = load(os.path.join(HERE, "data"))
    states, ignored = final_states(rows)
    apps = list(states.values())
    total = len(apps)
    status_counts = Counter(a["status"] for a in apps)
    decided = total - status_counts["IN_PROGRESS"]
    granted = [a for a in apps if a["granted_limit"]]
    granted_sum = sum(int(a["granted_limit"]) for a in granted)

    # straight-through = completed without ever being referred or failing
    stp = sum(1 for a in apps if a["status"] == "COMPLETED"
              and not a["decline_reason_code"])

    # ---- weekly trend (30 weeks reads; 209 days does not) -----------------
    weeks = defaultdict(Counter)
    for a in apps:
        day = dt.date.fromisoformat(a["submitted_at"][:10])
        weeks[day - dt.timedelta(days=day.weekday())][a["status"]] += 1
    trend = [{"week": w.isoformat(), "total": sum(c.values()),
              "counts": {o: c[o] for o in OUTCOMES}, "failed": c["FAILED"]}
             for w, c in sorted(weeks.items())]

    # ---- funnel, with the leading reason at each step ---------------------
    stopped = defaultdict(Counter)
    for a in apps:
        if a["stopped_at_step"] and a["decline_reason_code"]:
            stopped[a["stopped_at_step"]][a["decline_reason_code"]] += 1
    funnel_rows = []
    for index, step, reached, passed, dropped in funnel(states):
        top = stopped[step].most_common(1)
        funnel_rows.append({
            "step": index, "domain": step, "reached": reached,
            "passed": passed, "dropped": dropped,
            "rate": round(100.0 * passed / max(1, reached), 1),
            "topReason": top[0][0] if top else "",
            "topReasonCount": top[0][1] if top else 0,
        })

    reasons = Counter(a["decline_reason_code"] for a in apps
                      if a["decline_reason_code"])

    # ---- requested vs granted, bucketed (never a scatter) ----------------
    ask = defaultdict(lambda: {"n": 0, "asked": 0, "granted": 0, "capped": 0})
    for a in granted:
        b = band_of(int(a["requested_limit"]), ASK_BANDS)
        ask[b]["n"] += 1
        ask[b]["asked"] += int(a["requested_limit"])
        ask[b]["granted"] += int(a["granted_limit"])
        if int(a["granted_limit"]) < int(a["requested_limit"]):
            ask[b]["capped"] += 1
    ask_rows = [{"label": label, "n": ask[label]["n"],
                 "avgAsked": round(ask[label]["asked"] / max(1, ask[label]["n"])),
                 "avgGranted": round(ask[label]["granted"] / max(1, ask[label]["n"])),
                 "cappedPct": round(100.0 * ask[label]["capped"]
                                    / max(1, ask[label]["n"]), 1)}
                for label, _, _ in ASK_BANDS if ask[label]["n"]]

    # ---- per-file load tallies (counting only; not a loader) -------------
    held, loads = {}, []
    immutable = ["submitted_at", "channel", "product_code", "requested_limit"]
    by_day = defaultdict(list)
    for r in rows:
        by_day[r["_day"]].append(r)
    rejects_by_day = Counter(d for d, _, _, _ in bad)
    for day in sorted(by_day):
        tally = Counter()
        for r in sorted(by_day[day], key=lambda x: (x["last_updated_at"],
                                                    x["application_id"])):
            prior = held.get(r["application_id"])
            if prior is None:
                tally["new"] += 1
            elif parse_ts(r["last_updated_at"]) <= parse_ts(prior["last_updated_at"]):
                tally["unchanged"] += 1
                continue
            elif any(prior[c] != r[c] for c in immutable):
                tally["restated"] += 1
            else:
                tally["updated"] += 1
            held[r["application_id"]] = r
        loads.append({
            "date": day.isoformat(),
            "read": len(by_day[day]) + rejects_by_day[day],
            "new": tally["new"], "updated": tally["updated"],
            "unchanged": tally["unchanged"], "restated": tally["restated"],
            "rejected": rejects_by_day[day],
        })

    days = sorted(by_day)
    span = (days[-1] - days[0]).days + 1
    gaps = [(days[0] + dt.timedelta(days=i)).isoformat() for i in range(span)
            if days[0] + dt.timedelta(days=i) not in set(days)]

    sample = sorted(apps, key=lambda a: a["submitted_at"], reverse=True)[:8]

    data = {
        "meta": {
            "periodFrom": "2026-01-01", "periodTo": "2026-07-28",
            "files": len(files), "businessDates": span, "gaps": gaps,
            "rowsInFiles": len(rows) + len(bad), "malformed": len(bad),
            "staleIgnored": ignored,
            "multiFileApps": sum(1 for _, c in Counter(
                r["application_id"] for r in rows).items() if c > 1),
        },
        "kpi": {
            "applications": total,
            "approved": status_counts["COMPLETED"],
            "approvalRate": round(100.0 * status_counts["COMPLETED"]
                                  / max(1, decided), 1),
            "grantedTotal": granted_sum,
            "avgGranted": round(granted_sum / max(1, len(granted))),
            "stpRate": round(100.0 * stp / max(1, total), 1),
        },
        "outcomes": [{"label": o, "value": status_counts[o]} for o in OUTCOMES],
        "failed": status_counts["FAILED"],
        "trend": trend,
        "funnel": funnel_rows,
        "reasons": [{"code": c, "value": n, "team": c[:3]}
                    for c, n in reasons.most_common()],
        "byChannel": as_series(split(apps, lambda r: r["channel"])),
        "byProduct": as_series(split(apps, lambda r: r["product_code"])),
        "byIncome": as_series(split(apps, lambda r: band_of(
            int(r["annual_income"]), INCOME_BANDS)),
            order=[b[0] for b in INCOME_BANDS]),
        "byDti": as_series(split(apps, lambda r: band_of(
            float(r["dti_ratio"]), DTI_BANDS)),
            order=[b[0] for b in DTI_BANDS]),
        "byBand": as_series(split(apps, lambda r: r["credit_band"]),
                            order=list("ABCDE")),
        "byAge": as_series(split(apps, lambda r: r["age_band"]),
                           order=["18-24", "25-34", "35-44", "45-54",
                                  "55-64", "65+"]),
        "byEmployment": as_series(split(apps, lambda r: r["employment_status"])),
        "ask": ask_rows,
        "moneyByProduct": [
            {"label": p, "granted": sum(int(a["granted_limit"]) for a in granted
                                        if a["product_code"] == p),
             "requested": sum(int(a["requested_limit"]) for a in apps
                              if a["product_code"] == p)}
            for p in sorted({a["product_code"] for a in apps})],
        "screening": dict(Counter(a["screening_outcome"] for a in apps
                                  if a["screening_outcome"])),
        "kyc": dict(Counter(a["kyc_outcome"] for a in apps if a["kyc_outcome"])),
        "agreement": dict(Counter(a["agreement_outcome"] for a in apps
                                  if a["agreement_outcome"])),
        "loads": loads,
        "rejections": [{"date": d.isoformat(), "line": n, "reason": why,
                        "raw": (row.get("application_id") or "(blank)") + "," +
                               row.get("submitted_at", "") + "," +
                               row.get("channel", "") + ",…"}
                       for d, n, why, row in bad],
        "sample": [{k: a[k] for k in
                    ["application_id", "submitted_at", "channel",
                     "product_code", "requested_limit", "status",
                     "steps_reached", "stopped_at_step", "decline_reason_code",
                     "granted_limit", "credit_band", "dti_ratio"]}
                   for a in sample],
    }

    out = os.path.join(HERE, "chart_data.json")
    with open(out, "w", encoding="utf-8") as handle:
        json.dump(data, handle, separators=(",", ":"), sort_keys=False)
    print("wrote %s (%.1f KB)" % (out, os.path.getsize(out) / 1024))

    # Inline it into the mock, which must stay self-contained and offline.
    page = os.path.join(HERE, "dashboards.html")
    if os.path.exists(page):
        import re
        with open(page, encoding="utf-8") as handle:
            html = handle.read()
        blob = json.dumps(data, separators=(",", ":"), sort_keys=False)
        html, count = re.subn(r"^const DATA = .*$",
                              lambda _: "const DATA = " + blob + ";",
                              html, count=1, flags=re.M)
        if count != 1:
            sys.exit("could not find the `const DATA = …` line in dashboards.html")
        with open(page, "w", encoding="utf-8") as handle:
            handle.write(html)
        print("inlined into %s (%.1f KB)" % (page, os.path.getsize(page) / 1024))
    return 0


if __name__ == "__main__":
    sys.exit(main())
