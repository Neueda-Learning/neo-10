#!/usr/bin/env python3
"""Recount the feed from the CSVs alone, and write answers.md.

This script deliberately does NOT import generate_daily_feed.py. It reads the
files on disk exactly as team 10's loader will, so if the generator's own idea
of the answer disagreed with what it actually wrote, this is what catches it.

It is a COUNTER, not a loader: it applies the newest-wins rule to work out each
application's final state, and stops there. Building the batch tallies, the
rejection log and the gap report is the team's work, and doing it here would
create the third parser the review complains about.

Usage:  python3 verify_feed.py [--data data] [--out answers.md]
Exit code is non-zero if any assertion about the planted anomalies fails.
"""
import argparse
import csv
import datetime as dt
import glob
import os
import re
import sys
from collections import Counter, defaultdict

STEPS = ["verification", "policy", "kyc", "screening",
         "credit", "agreement", "account", "card"]
VALID_STATUS = {"COMPLETED", "REJECTED", "REFERRED", "IN_PROGRESS", "FAILED"}
VALID_CHANNEL = {"WEB", "MOBILE_APP", "BRANCH", "AGGREGATOR"}
VALID_PRODUCT = {"CREDIT_CARD_PREMIUM", "CREDIT_CARD_PLATINUM"}
TS = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")

FAILURES = []


def check(condition, message):
    if condition:
        print("  ok   %s" % message)
    else:
        print("  FAIL %s" % message)
        FAILURES.append(message)


def parse_ts(value):
    return dt.datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")


def row_problem(row):
    """The same validation a loader would apply, line by line."""
    if not row.get("application_id"):
        return "missing application_id"
    if not TS.match(row.get("submitted_at", "")):
        return "submitted_at is not an ISO-8601 UTC timestamp"
    if row.get("channel") not in VALID_CHANNEL:
        return "unknown channel %r" % row.get("channel")
    if row.get("product_code") not in VALID_PRODUCT:
        return "unknown product_code %r" % row.get("product_code")
    if not str(row.get("requested_limit", "")).isdigit():
        return "requested_limit is not an integer"
    if row.get("status") not in VALID_STATUS:
        return "unknown status %r" % row.get("status")
    if not TS.match(row.get("last_updated_at", "")):
        return "last_updated_at is not an ISO-8601 UTC timestamp"
    return None


def load(data_dir):
    files = sorted(glob.glob(os.path.join(data_dir, "neo_daily_*.csv")))
    if not files:
        sys.exit("no daily files found in %s — run generate_daily_feed.py first"
                 % data_dir)
    good, bad, per_file = [], [], []
    for path in files:
        day = dt.date.fromisoformat(os.path.basename(path)[10:20])
        with open(path, newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        ok = [r for r in rows if row_problem(r) is None]
        broken = [(day, i + 2, row_problem(r), r) for i, r in enumerate(rows)
                  if row_problem(r) is not None]
        for r in ok:
            r["_day"] = day
        good.extend(ok)
        bad.extend(broken)
        per_file.append((day, len(rows), len(ok), len(broken)))
    return files, good, bad, per_file


def final_states(rows):
    """Newest-wins per application_id — the upsert rule, applied for counting.

    Rows are visited in file order and, within a file, in the order written; a
    row whose last_updated_at is not newer than the one already held is ignored,
    which is exactly what the out-of-order guard must do.
    """
    latest, ignored = {}, 0
    for row in sorted(rows, key=lambda r: (r["_day"], r["last_updated_at"],
                                           r["application_id"])):
        held = latest.get(row["application_id"])
        if held is None:
            latest[row["application_id"]] = row
        elif parse_ts(row["last_updated_at"]) > parse_ts(held["last_updated_at"]):
            latest[row["application_id"]] = row
        else:
            ignored += 1
    return latest, ignored


def funnel(states):
    """reached(N) = steps_reached >= N-1 · passed(N) = steps_reached >= N.

    That works only because the journey is strictly sequential (the orchestrator
    dispatches one step at a time and only ACCEPTED advances), so an application
    that passed k steps necessarily reached step k+1 and every step before it.
    """
    reached_counts = Counter(int(r["steps_reached"]) for r in states.values())
    table = []
    for index, step in enumerate(STEPS, start=1):
        reached = sum(c for k, c in reached_counts.items() if k >= index - 1)
        passed = sum(c for k, c in reached_counts.items() if k >= index)
        table.append((index, step, reached, passed, reached - passed))
    return table


def money(value):
    return "£{:,}".format(int(value))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    here = os.path.dirname(os.path.abspath(__file__))
    parser.add_argument("--data", default=os.path.join(here, "data"))
    parser.add_argument("--out", default=os.path.join(here, "answers.md"))
    args = parser.parse_args()

    files, rows, bad, per_file = load(args.data)
    states, ignored_stale = final_states(rows)

    days = sorted({d for d, *_ in per_file})
    span = (days[-1] - days[0]).days + 1
    missing_days = [days[0] + dt.timedelta(days=i) for i in range(span)
                    if days[0] + dt.timedelta(days=i) not in set(days)]

    status_counts = Counter(r["status"] for r in states.values())
    total = len(states)
    completed = status_counts["COMPLETED"]

    print("\n== assertions ==")
    check(len(files) == 208, "208 daily files on disk (209 dates, one absent)")
    check(len(missing_days) == 1 and missing_days[0] == dt.date(2026, 4, 17),
          "exactly one gap in the business-date sequence: 2026-04-17")
    check(len(bad) > 0, "%d malformed rows present, each rejectable on its own "
                        "line" % len(bad))
    check(all(row_problem(r) is not None for _, _, _, r in bad),
          "every counted malformed row genuinely fails validation")

    dup_files = [(d, aid) for d, *_ in per_file for aid, c in Counter(
        r["application_id"] for r in rows if r["_day"] == d).items() if c > 1]
    check(len(dup_files) >= 1,
          "at least one file contains the same application_id twice "
          "(%s in %s)" % (dup_files[0][1], dup_files[0][0]) if dup_files
          else "duplicate application_id within one file")

    check(ignored_stale >= 1,
          "%d row(s) arrived carrying a last_updated_at no newer than one "
          "already loaded — the out-of-order guard has something to catch"
          % ignored_stale)

    seen_limits = defaultdict(set)
    for r in rows:
        seen_limits[r["application_id"]].add(r["requested_limit"])
    restated = sorted(a for a, v in seen_limits.items() if len(v) > 1)
    check(len(restated) >= 1,
          "at least one application's immutable requested_limit changes "
          "between files (%s)" % (restated[0] if restated else "-"))

    spike = dt.date(2026, 3, 12)
    spike_new = len([r for r in rows if r["_day"] == spike
                     and r["submitted_at"][:10] == spike.isoformat()])
    neighbour = [len([r for r in rows if r["_day"] == d
                      and r["submitted_at"][:10] == d.isoformat()])
                 for d in (spike - dt.timedelta(days=7),
                           spike + dt.timedelta(days=7))]
    check(spike_new > 2 * max(neighbour),
          "2026-03-12 carries %d new applications vs %s on the same weekday "
          "either side" % (spike_new, neighbour))

    dip = [d for d in days if dt.date(2026, 6, 8) <= d <= dt.date(2026, 6, 14)]
    def plat_rate(window):
        pool = [s for s in states.values()
                if s["product_code"] == "CREDIT_CARD_PLATINUM"
                and dt.date.fromisoformat(s["submitted_at"][:10]) in window]
        if not pool:
            return 0.0
        return sum(1 for s in pool if s["status"] == "COMPLETED") / len(pool)
    dip_rate = plat_rate(set(dip))
    base_rate = plat_rate({d for d in days if d not in set(dip)})
    check(dip_rate < base_rate - 0.10,
          "PLATINUM approval dips to %.1f%% in the week of 2026-06-08 vs "
          "%.1f%% elsewhere" % (dip_rate * 100, base_rate * 100))

    check(sum(len(v) for v in [rows]) == sum(ok for _, _, ok, _ in per_file),
          "row totals reconcile across all files")

    # ---------------------------------------------------------------- report
    reasons = Counter(r["decline_reason_code"] for r in states.values()
                      if r["decline_reason_code"])
    by_channel = defaultdict(Counter)
    for s in states.values():
        by_channel[s["channel"]][s["status"]] += 1
    by_product = defaultdict(Counter)
    for s in states.values():
        by_product[s["product_code"]][s["status"]] += 1
    granted_total = sum(int(s["granted_limit"]) for s in states.values()
                        if s["granted_limit"])
    granted_rows = [s for s in states.values() if s["granted_limit"]]
    capped = sum(1 for s in granted_rows
                 if int(s["granted_limit"]) < int(s["requested_limit"]))

    lines = []
    add = lines.append
    add("# Answer key — neo-10 daily feed\n")
    add("Computed by `verify_feed.py` **from the generated CSVs only** — it "
        "does not import the generator. Regenerating with seed 42 reproduces "
        "every number here exactly. If your dashboard disagrees with this "
        "file, your dashboard is wrong.\n")
    add("## The feed\n")
    add("| | |\n|---|---|")
    add("| Business dates in the period | %d (2026-01-01 → 2026-07-28) |" % span)
    add("| Daily files on disk | **%d** |" % len(files))
    add("| Missing business date | **%s** — the file never arrived |"
        % missing_days[0].isoformat())
    add("| Rows across all files | %d |" % (len(rows) + len(bad)))
    add("| …that parse | %d |" % len(rows))
    add("| …malformed, one rejectable line each | **%d** |" % len(bad))
    add("| Distinct applications after loading | **%d** |" % total)
    add("| Rows ignored by the out-of-order guard | **%d** |" % ignored_stale)
    add("| Applications appearing in more than one file | %d |"
        % sum(1 for a, c in Counter(r["application_id"] for r in rows).items()
              if c > 1))
    add("")
    add("## Outcome summary — the whole period\n")
    add("| status | count | share |\n|---|---:|---:|")
    for status in ["COMPLETED", "REJECTED", "REFERRED", "IN_PROGRESS", "FAILED"]:
        n = status_counts[status]
        add("| `%s` | %d | %.1f%% |" % (status, n, 100.0 * n / total))
    add("| **total** | **%d** | 100.0%% |" % total)
    add("")
    add("Approval rate (COMPLETED ÷ decided) = **%.1f%%**. "
        "Conversion (COMPLETED ÷ all) = **%.1f%%**. These are not the same "
        "number and the difference is the most common reporting mistake there "
        "is — publish which one your tile shows.\n"
        % (100.0 * completed / max(1, total - status_counts["IN_PROGRESS"]),
           100.0 * completed / total))
    add("## Step funnel — 8 steps, from two columns\n")
    add("| # | step | reached | passed | dropped | pass rate |")
    add("|---|---|---:|---:|---:|---:|")
    for index, step, reached, passed, dropped in funnel(states):
        add("| %d | `%s` | %d | %d | %d | %.1f%% |"
            % (index, step, reached, passed, dropped,
               100.0 * passed / max(1, reached)))
    add("")
    add("`reached(N) = count(steps_reached >= N-1)` and "
        "`passed(N) = count(steps_reached >= N)`. That works only because the "
        "journey is strictly sequential — `stopped_at_step` is needed to say "
        "*why* a drop happened, not to count it.\n")
    add("## Decline reasons — the Pareto\n")
    add("One code per application: the deciding step's first reason. "
        "Populated for `REJECTED`, `REFERRED` and `FAILED`; empty for "
        "`COMPLETED` and `IN_PROGRESS`.\n")
    add("| reason code | owned by | count |\n|---|---|---:|")
    owner = {"VER": "team 1 · verification", "POL": "team 2 · policy",
             "KYC": "team 3 · kyc", "SCR": "team 4 · screening",
             "CRE": "team 5 · credit", "AGR": "team 6 · agreement",
             "ACC": "team 7 · account", "CRD": "team 8 · card"}
    for code, count in reasons.most_common():
        add("| `%s` | %s | %d |" % (code, owner.get(code[:3], "-"), count))
    add("| **total** | | **%d** |" % sum(reasons.values()))
    add("")
    add("## Channel\n")
    add("| channel | applications | completed | approval rate |")
    add("|---|---:|---:|---:|")
    for channel in sorted(by_channel, key=lambda c: -sum(by_channel[c].values())):
        counts = by_channel[channel]
        n = sum(counts.values())
        decided = n - counts["IN_PROGRESS"]
        add("| `%s` | %d | %d | %.1f%% |"
            % (channel, n, counts["COMPLETED"],
               100.0 * counts["COMPLETED"] / max(1, decided)))
    add("")
    add("## Product\n")
    add("| product | applications | completed | approval rate | APR |")
    add("|---|---:|---:|---:|---:|")
    apr = {"CREDIT_CARD_PREMIUM": "24.9", "CREDIT_CARD_PLATINUM": "19.9"}
    for product in sorted(by_product):
        counts = by_product[product]
        n = sum(counts.values())
        decided = n - counts["IN_PROGRESS"]
        add("| `%s` | %d | %d | %.1f%% | %s |"
            % (product, n, counts["COMPLETED"],
               100.0 * counts["COMPLETED"] / max(1, decided), apr[product]))
    add("")
    add("## Money\n")
    add("| | |\n|---|---|")
    add("| Total limit granted | **%s** |" % money(granted_total))
    add("| Applications with a granted limit | %d |" % len(granted_rows))
    add("| Average granted limit | %s |"
        % money(granted_total / max(1, len(granted_rows))))
    add("| Granted below what was requested | %d (%.1f%%) |"
        % (capped, 100.0 * capped / max(1, len(granted_rows))))
    add("| Total limit requested, all applications | %s |"
        % money(sum(int(s["requested_limit"]) for s in states.values())))
    add("")
    add("## The seven planted anomalies\n")
    add("| # | anomaly | the answer |\n|---|---|---|")
    add("| 1 | The file that never arrived | `neo_daily_2026-04-17.csv` does "
        "not exist. The business-date sequence has exactly one hole. "
        "Applications submitted and decided that day are **lost for good** — "
        "a gap is not cosmetic. |")
    add("| 2 | A restatement | `%s` — an immutable column (`requested_limit`) "
        "changes in a later file. Overwrite, but **count it as `restated`** "
        "and show it. Silent is the wrong answer. |"
        % (restated[0] if restated else "-"))
    add("| 3 | Malformed rows | **%d** across the period, spread thinly: bad "
        "date format, unknown enum, missing key, non-numeric limit, invalid "
        "status. Each rejects **its own line**; the rest of the file loads. A "
        "422 that kills the file throws away good data. |" % len(bad))
    add("| 4 | Duplicate id within one file | `%s` appears twice in "
        "`neo_daily_%s.csv`, the second occurrence newer. Filename-level "
        "dedupe cannot see this — only a row-level rule can. |"
        % ((dup_files[0][1], dup_files[0][0].isoformat()) if dup_files
           else ("-", "-")))
    add("| 5 | An out-of-order update | **%d** row(s) arrive carrying a "
        "`last_updated_at` no newer than the version already loaded. Applying "
        "one would undo a decision. Skip it and count it `unchanged`. |"
        % ignored_stale)
    add("| 6 | The campaign spike | 2026-03-12 carries **%d** new "
        "applications against ~%d on the same weekday either side, mostly "
        "`AGGREGATOR`, asking for more and approved less. Only the channel "
        "slice explains the dip in that week's overall rate. |"
        % (spike_new, sum(neighbour) // 2))
    add("| 7 | The PLATINUM dip | Week of 2026-06-08 → 06-14: PLATINUM "
        "approval **%.1f%%** against **%.1f%%** across the rest of the "
        "period. Invisible on any chart that does not cross product with "
        "time. |" % (dip_rate * 100, base_rate * 100))
    add("")
    ties = defaultdict(set)
    for r in rows:
        ties[r["last_updated_at"]].add(r["application_id"])
    biggest = max(ties.items(), key=lambda kv: len(kv[1]))
    add("## One more thing, which matters only in Part 2\n")
    add("**%d different applications share the exact timestamp `%s`.**\n"
        % (len(biggest[1]), biggest[0]))
    add("A file loader never notices — it reads the whole file. A *table* "
        "reader paging on `WHERE last_updated_at > :watermark … LIMIT n` "
        "loses whatever is left of that group when the batch boundary lands "
        "inside it, and switching to `>=` re-reads it forever instead. "
        "Neither is a hypothetical: this group is 12 rows, so any batch size "
        "that is not a multiple of the group offset will split it.\n")
    add("The fix is a composite keyset — `(last_updated_at, application_id) > "
        "(:watermark, :lastKey)` — and the reason it is *safe* is the "
        "idempotent upsert you already wrote for the files. Part 2 is where "
        "that lands.\n")
    add("| tie groups spanning more than one application | %d |\n|---|---:|"
        % sum(1 for v in ties.values() if len(v) > 1))
    add("| largest group | %d applications at `%s` |"
        % (len(biggest[1]), biggest[0]))
    add("")
    add("## Load tallies per file — the shape to expect\n")
    add("Busiest and quietest files, for sanity-checking your `daily_load` "
        "rows:\n")
    add("| business date | rows in file | parse | reject |")
    add("|---|---:|---:|---:|")
    busiest = sorted(per_file, key=lambda t: -t[1])[:3]
    quietest = sorted(per_file, key=lambda t: t[1])[:2]
    for day, read, ok, broken in busiest + quietest:
        add("| %s | %d | %d | %d |" % (day.isoformat(), read, ok, broken))
    add("")
    add("---\n")
    add("Regenerate: `python3 generate_daily_feed.py` · "
        "recheck: `python3 verify_feed.py`\n")

    with open(args.out, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines))

    print("\nwrote %s" % args.out)
    if FAILURES:
        print("\n%d ASSERTION(S) FAILED" % len(FAILURES))
        return 1
    print("all assertions passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
